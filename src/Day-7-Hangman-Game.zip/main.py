#import required modules and libraries
import random
from hangman_words import words
from hangman_ascii import hangman_logo, hangman_stages
from replit import clear


word = random.choice(words)

hidden_word = []

for letter in word:
    hidden_word.append("_")

lives = 6
end_of_game = False

while not end_of_game:
  clear()
  print(word)
  print(hangman_logo)
  print(hidden_word)
  print(hangman_stages[lives])
  print(lives)
  guess = input("guess a letter:")
  
  for index in range(len(word)):
    if word[index] == guess:
      hidden_word[index] = guess
  
  if '_' not in hidden_word:
    end_of_game = True
    print(f"You win! Guessed word: {word}")


  if guess not in word:
    if lives == 1 :
      end_of_game = True
      print(f"You lose , the word was {word}")
    else :
      lives -= 1
  

