from art import logo, vs
from game_data import data
from random import choice
from replit import clear


compared_accounts = []

def get_data():
  account = choice(data)
  if account not in compared_accounts :
    compared_accounts.append(account)
    return account
  else :
    return get_data()

def print_comparison(A, B):
  print(f"Compare A : {A['name']}, a {A['description']} from {A['country']}")
  print(vs)
  print(f"Against B : {B['name']}, a {B['description']} from {B['country']}")

def compare_follower_count(A , B ):
  """returns account which has more followers"""
  if A['follower_count'] > B['follower_count'] :
    return "A"
  else :
    return "B"

  
    
def get_answer(A , B , answer):
  winner = compare_follower_count(A , B)
  return winner == answer


def high_low():
  A = get_data()
  score = 0
  result  = True
  while result :
    clear()
    print(logo)
    B = get_data()
    if score != 0:
      print(f"You are right! Current score: {score}")
    print_comparison(A , B)
    answer = input("Who has more followers? Type 'A' or 'B' : ")
    result = get_answer(A , B , answer)
  
    if result :
      score += 1
      print(f"You are right! Current score: {score}")
      A = B
    else:
      print(f"Sorry that's wrong. Final score: {score}")
      score = 0
      if input("Play again? 'y' for yes 'n' for No : ") == 'y':
        high_low()
        global compared_accounts
        compared_accounts = []
    
  
      

high_low()
