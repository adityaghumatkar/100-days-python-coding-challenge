def add(num1 , num2):
  return num1 + num2

def subtract(num1 , num2):
  return num1 - num2

def multiply(num1 , num2):
  return num1 * num2

def divide(num1 , num2):
  return num1 / num2

operations = {
  "+" : add,
  "-" : subtract,
  "*" : multiply,
  "/" : divide
}

def calculator():

  num1 = float(input("What is the first number? "))
  
  for symbol in operations:
    print(symbol)
    
  should_continue = True
  
  while should_continue :

    operation_symbol = input("Pick an operation : ")
    num2 = float(input("What is the next number? "))
    
    
    calculation_function = operations[operation_symbol]
    
    answer = calculation_function(num1 , num2)
    print(f"{num1} {operation_symbol} {num2} = {answer}")
  
    next_step = input("Do you want to continue? Type 'y' for yes and 'n' for no and 'new' for new calculation: ")
  
    if next_step == "y":
      num1 = answer
    elif next_step == "n":
      should_continue = False
    else:
      should_continue = False
      calculator()

calculator()

  


