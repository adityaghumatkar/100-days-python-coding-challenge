rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
import random

choice = int(input("What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors.\n"))
computers_choice = random.randint(0,2)

game_images = [rock, paper, scissors]

##print hand signs
if choice >= 3 or choice < 0:
  print("You typed an invalid number, you lose!")
else:
    print(f"you chose : \n {game_images[choice]}")
    print(f"Computer chose : \n{game_images[computers_choice]}")

    ##win loose logic
    if choice == computers_choice:
        print("Draw")
    elif choice == 0 and computers_choice == 1:
        print("You lose")
    elif choice == 0 and computers_choice == 2:
        print("You win")
    elif choice == 1 and computers_choice == 0:
        print("You win")
    elif choice == 1 and computers_choice == 2:
        print("You lose")
    elif choice == 2 and computers_choice == 0:
        print("You lose")
    elif choice == 2 and computers_choice == 1:
        print("You win")
    else :
        print("You loose")

