from replit import clear
from art import logo

print(logo)


#bids_list = []
more_bidders = True
bids = {}
def add_bid(name, bid):
    
    bids[name] = bid
    # bids_list.append(bids)
    # print(bids)

while more_bidders :

  bidder_name = input("What is your name?\n")
  bid_amount = int(input("What is your bid?:\n$"))
  
  add_bid(name = bidder_name, bid = bid_amount)
  next_bidder = input("Are there any other bidders? Type 'yes' or 'no'.\n")

  if next_bidder == "no":
    more_bidders = False
  else :
    clear()
    

def get_winner():
  highest_bid = 0
  winner = ""
  for item in bids :
     if bids[item] > highest_bid:
       highest_bid = bids[item]
       winner = item

  print(f"The winner is {winner} with a bid of ${highest_bid}")

if not more_bidders :
  get_winner()

print(bids)