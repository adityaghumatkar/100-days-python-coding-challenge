class Animal:
  def __init__(self):
    self.no_of_eyes = 2

  def move(self):
    print(f"animal moving!!{self.no_of_eyes}")


class Lion(Animal):
  def __init__(self):
    super().__init__()
    self.no_of_eyes = 4

  def move(self):
    super().move()
    # print("lion moving")

lion = Lion()
lion.move()



list = [1,2,3,4,5,6,7,8,9]
print(list[-2::-1])